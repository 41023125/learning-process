function repeat1()
    return [[
i = 5

repeat
  i = i - 1
  print(i)
until i == 1
    ]]
end